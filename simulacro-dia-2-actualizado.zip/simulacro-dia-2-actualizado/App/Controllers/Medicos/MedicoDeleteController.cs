using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Services.Medicos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Medicos
{
    public class MedicoDeleteController : ControllerBase
    {
        private readonly IMedicoRepository _medicoRepository;
        public MedicoDeleteController(IMedicoRepository medicoRepository)
        {
            _medicoRepository = medicoRepository;
        }

        [HttpDelete("{id}")]
        [Route("api/medicos/delete/{id}")]
        public IActionResult Delete(int id)
        {
            _medicoRepository.Delete(id);
            return Ok(new { message = "El Medico Ha Cambiado de Estdo Correctamente" });
        }
    }
}