using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services.Medicos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Medicos
{
    public class MedicoUpdateController : ControllerBase
    {
        private readonly IMedicoRepository _medicoRepository;
        public MedicoUpdateController(IMedicoRepository medicoRepository)
        {
            _medicoRepository = medicoRepository;
        }

        [HttpPut("{id}")]
        [Route("api/medicos/update/{id}")]
        public IActionResult Update(int id, [FromBody] Medico medico)
        {
            if(medico == null)
            {
                return BadRequest("El medico proporcionado no puede ser nulo");
            }

            // Obtener el medico existente por id
            var medicoExistente = _medicoRepository.GetById(id);

            // Verificar que el medico existente no sea null
            if (medicoExistente == null)
            {
                return NotFound($"No se encontró un medico con el id {id} en la base de datos");
            }

            medicoExistente.NombreCompleto = medico.NombreCompleto;
            medicoExistente.Correo = medico.Correo;
            medicoExistente.Telefono = medico.Telefono;
            medicoExistente.EspecialidadId = medico.EspecialidadId;
            medicoExistente.Estado = medico.Estado;

            _medicoRepository.Update(medicoExistente);
            return Ok(new { message = "El medico se actualizó correctamente" });


        }
        
    }
}