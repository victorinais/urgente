using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services.Medicos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Medicos
{
    public class MedicoCreateController : ControllerBase
    {
        private readonly IMedicoRepository _medicoRepository;
        public MedicoCreateController(IMedicoRepository medicoRepository)
        {
            _medicoRepository = medicoRepository;
        }

        [HttpPost]
        [Route("api/medicos/create")]
        public IActionResult Create([FromBody] Medico medico)
        {
            if(medico == null)
            {
                return BadRequest("El Objeto es nulo");
            }
            _medicoRepository.Add(medico);
            return Ok(new { message = "El Medico Se Ha Creado Correctamente" });
        }
        

    }
}