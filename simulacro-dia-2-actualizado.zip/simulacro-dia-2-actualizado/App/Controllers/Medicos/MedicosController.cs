using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services.Medicos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Medicos
{
    public class MedicosController : ControllerBase
    {
        private readonly IMedicoRepository _medicoRepository;
        public MedicosController(IMedicoRepository medicoRepository)
        {
            _medicoRepository = medicoRepository;
        }

        [HttpGet]
        [Route("api/medicos")]
        public IEnumerable<Medico> GetMedicos(){
            return _medicoRepository.GetAll();
        }
        [HttpGet]
        [Route("api/medicos/{id}")]
        public Medico Details(int id){
            return _medicoRepository.GetById(id);
        }
        
    }
}