using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;


namespace App.Controllers.Citas
{
    public class CitaUpdateController : ControllerBase
    {
        private readonly ICitaRepository _citaRepository;
        public CitaUpdateController(ICitaRepository citaRepository)
        {
            _citaRepository = citaRepository;
        }
        
        [HttpPut("{id}")]
        [Route("api/citas/update/{id}")]
        public IActionResult Update(int id, [FromBody] Cita cita)
        {
            if(cita == null)
            {
                return BadRequest("La cita proporcionada no puede ser nula");
            }
            
            // Obtener la cita existente por id
            var citaExistente = _citaRepository.GetById(id);

            // Verificar que la cita existente no sea null
            if (citaExistente == null)
            {
                return NotFound($"No se encontró una cita con el id {id} en la base de datos");
            }

            citaExistente.MedicoId = cita.MedicoId;
            citaExistente.PacienteId = cita.PacienteId;
            citaExistente.Fecha = cita.Fecha;
            citaExistente.Estado = cita.Estado; 

            _citaRepository.Update(citaExistente);
            return Ok(new { message = "La cita se actualizó correctamente" });
            

        }
    }
}