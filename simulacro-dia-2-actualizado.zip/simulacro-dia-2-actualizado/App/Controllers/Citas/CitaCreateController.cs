using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Citas
{
    public class CitaCreateController : ControllerBase
    {
        private readonly ICitaRepository _citaRepository;
        public CitaCreateController(ICitaRepository citaRepository)
        {
            _citaRepository = citaRepository;
        }

        [HttpPost]
        [Route("api/citas/create")]
        public IActionResult Create([FromBody] Cita cita)
        {
            if(cita == null)
            {
                return BadRequest("El Objeto es nulo");
            }
            _citaRepository.Add(cita);
            return Ok(new { message = "La cita Se Ha Creado Correctamente" });
        }
    }
}