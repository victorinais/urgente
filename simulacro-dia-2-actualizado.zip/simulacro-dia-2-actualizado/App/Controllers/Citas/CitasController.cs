using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Citas
{
    public class CitasController : ControllerBase
    {
        private readonly ICitaRepository _citaRepository;
        public CitasController(ICitaRepository citaRepository)
        {
            _citaRepository = citaRepository;
        }

        [HttpGet]
        [Route("api/citas")]
        public IEnumerable<Cita> GetCitas(){
            return _citaRepository.GetAll();
        }
        
        [HttpGet]
        [Route("api/citas/{id}")]
        public Cita Details(int id){
            return _citaRepository.GetById(id);
        }

        [HttpGet("api/count/date/{date}")]
        public ActionResult<int> GetCitaCountByDate(DateTime date) 
        {
            var count = _citaRepository.GetCitaCountByDate(DateOnly.FromDateTime(date));
            return Ok(new { messagge = $"En la fecha {date.ToString("yyyy-MM-dd")} se agendaron {count} citas."});
        }

        [HttpGet("api/count/medico/{medicoId}/date/{date}")]
        public ActionResult<IEnumerable<Cita>> GetCitasByMedicoAndDate(int medicoId, DateTime date) 
        {
            var data = _citaRepository.GetCitasByMedicoAndDate(medicoId, DateOnly.FromDateTime(date));
            return Ok(new { messagge = $"El medico {medicoId} tuvo {data.Count()} citas en la fecha {date.ToString("yyyy-MM-dd")}.", citas = data});
        }
    }
}