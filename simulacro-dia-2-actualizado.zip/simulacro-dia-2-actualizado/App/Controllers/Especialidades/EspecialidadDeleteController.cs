using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Especialidades
{
    public class EspecialidadDeleteController : ControllerBase
    {
        private readonly IEspecialidadRepository _especialidadRepository;
        public EspecialidadDeleteController(IEspecialidadRepository especialidadRepository)
        {
            _especialidadRepository = especialidadRepository;
        }

        [HttpDelete("{id}")]
        [Route("api/especialidad/delete/{id}")]
        public IActionResult Delete(int id)
        {
            _especialidadRepository.Delete(id);
            return Ok(new { message = "La Especialidad Ha Cambiado de Estdo Correctamente" });
        }
    }
}