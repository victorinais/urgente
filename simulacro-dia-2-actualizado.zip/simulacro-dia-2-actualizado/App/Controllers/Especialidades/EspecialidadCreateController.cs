using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Especialidades
{
    public class EspecialidadCreateController : ControllerBase
    {
        private readonly IEspecialidadRepository _especialidadRepository;
        public EspecialidadCreateController(IEspecialidadRepository especialidadRepository)
        {
            _especialidadRepository = especialidadRepository;
        }

        [HttpPost]
        [Route("api/especialidad/create")]
        public IActionResult Create([FromBody] Especialidad especialidad)
        {
            if(especialidad == null)
            {
                return BadRequest("El Objeto es nulo");
            }
            _especialidadRepository.Add(especialidad);
            return Ok(new { message = "La Especialidad Se Ha Creado Correctamente" });
        }
    }
}