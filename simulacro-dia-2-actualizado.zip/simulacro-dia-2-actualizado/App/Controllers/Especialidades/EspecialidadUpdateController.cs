using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;


namespace App.Controllers.Especialidades
{
    public class EspecialidadUpdateController : ControllerBase
    {
        private readonly IEspecialidadRepository _especialidadRepository;
        public EspecialidadUpdateController(IEspecialidadRepository especialidadRepository)
        {
            _especialidadRepository = especialidadRepository;
        }

        [HttpPut("{id}")]
        [Route("api/especialidad/update/{id}")]
        public IActionResult Update(int id, [FromBody] Especialidad especialidad)
        {
            if(especialidad == null)
            {
                return BadRequest("La especialidad proporcinada no puede ser nula");
            }

            // Obtener la cita existente por id
            var especialidadExistente = _especialidadRepository.GetById(id);

            // Verificar que la cita existente no sea null
            if (especialidadExistente == null)
            {
                return NotFound($"No se encontró una especialidad con el id {id} en la base de datos");
            }

            especialidadExistente.Nombre = especialidad.Nombre;
            especialidadExistente.Descripcion = especialidad.Descripcion;
            especialidadExistente.Estado = especialidad.Estado;

            _especialidadRepository.Update(especialidadExistente);
            return Ok(new { message = "La Especialidad Se Ha Actualizado Correctamente" });
        }
    }
}