using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Especialidades
{
    public class EspecialidadesController : ControllerBase
    {
        private readonly IEspecialidadRepository _especialidadRepository;
        public EspecialidadesController(IEspecialidadRepository especialidadRepository)
        {
            _especialidadRepository = especialidadRepository;
        }

        [HttpGet]
        [Route("api/especialidades")]
        public IEnumerable<Especialidad> GetEspecialidades(){
            return _especialidadRepository.GetAll();
        }
        [HttpGet]
        [Route("api/especialidades/{id}")]
        public Especialidad Details(int id){
            return _especialidadRepository.GetById(id);
        }
    }
}