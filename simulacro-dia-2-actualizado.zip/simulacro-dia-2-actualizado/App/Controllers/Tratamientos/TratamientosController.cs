using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services.Tratamientos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Tratamientos
{
    public class TratamientosController : ControllerBase
    {
        public readonly ITratamientoRepository _tratamientoRepository;
        public TratamientosController(ITratamientoRepository tratamientoRepository)
        {
            _tratamientoRepository = tratamientoRepository;
        }

        [HttpGet]
        [Route("api/tratamientos")]
        public IEnumerable<Tratamiento> GetTratamientos()
        {
            return _tratamientoRepository.GetAll();
        }

        [HttpGet]
        [Route("api/tratamiento/{id}")]
        public Tratamiento Details(int id)
        {
            return _tratamientoRepository.GetById(id);
        }
    }
}