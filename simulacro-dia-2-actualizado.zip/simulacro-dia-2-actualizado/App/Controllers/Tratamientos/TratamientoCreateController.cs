using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services.Tratamientos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Tratamientos
{
    public class TratamientoCreateController : ControllerBase
    {
        private readonly ITratamientoRepository _tratamientoRepository;
        public TratamientoCreateController(ITratamientoRepository tratamientoRepository)
        {
            _tratamientoRepository = tratamientoRepository;
        }

        [HttpPost]
        [Route("api/tratamientos/create")]
        public IActionResult Create([FromBody] Tratamiento tratamiento)
        {
            if(tratamiento == null)
            {
                return BadRequest("El Objeto es nulo");
            }
            _tratamientoRepository.Add(tratamiento);
            return Ok(new { message = "El Tratamiento Se Ha Creado Correctamente" });
        }
    }
}