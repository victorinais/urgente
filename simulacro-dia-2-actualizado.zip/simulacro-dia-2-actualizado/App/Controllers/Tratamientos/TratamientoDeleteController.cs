using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Services.Tratamientos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Tratamientos
{
    public class TratamientoDeleteController : ControllerBase
    {
        private readonly ITratamientoRepository _tratamientoRepository;
        public TratamientoDeleteController(ITratamientoRepository tratamientoRepository)
        {
            _tratamientoRepository = tratamientoRepository;
        }

        [HttpDelete("{id}")]
        [Route("api/tratamiento/delete/{id}")]
        public IActionResult Delete(int id)
        {
            _tratamientoRepository.Delete(id);
            return Ok(new { message = "El tratamiento se eliminó correctamente" });
        }
    }
}