using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services.Tratamientos;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Tratamientos
{
    public class TratamientoUpdateController : ControllerBase
    {
        private readonly ITratamientoRepository _tratamientoRepository;
        public TratamientoUpdateController(ITratamientoRepository tratamientoRepository)
        {
            _tratamientoRepository = tratamientoRepository;
        }

        [HttpPut("{id}")]
        [Route("api/tratamiento/update/{id}")]
        public IActionResult Update(int id, [FromBody] Tratamiento tratamiento)
        {
            if(tratamiento == null)
            {
                return BadRequest("El tratamiento proporcionado no puede ser nulo");
            }

            // Obtener la cita existente por id
            var tratamientoExistente = _tratamientoRepository.GetById(id);

            if(tratamientoExistente == null)
            {
                return NotFound("El tratamiento no existe");
            }

            tratamientoExistente.CitaId = tratamiento.CitaId;
            tratamientoExistente.Descripcion = tratamiento.Descripcion;
            tratamientoExistente.Estado = tratamiento.Estado;

            _tratamientoRepository.Update(tratamientoExistente);
            return Ok(new { message = "El tratamiento se ha actualizado correctamente" });
        }

    }
}