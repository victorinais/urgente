using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Pacientes
{
    public class PacienteDeleteController : ControllerBase
    {
        private readonly IPacienteRepository _pacienteRepository;
        public PacienteDeleteController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }
        [HttpDelete("{id}")]
        [Route("api/paciente/delete/{id}")]
        public IActionResult Delete(int id)
        {
            _pacienteRepository.Delete(id);
            return Ok(new { message = "El Paciente Ha Cambiado de Estdo Correctamente" });
        }
    }
}