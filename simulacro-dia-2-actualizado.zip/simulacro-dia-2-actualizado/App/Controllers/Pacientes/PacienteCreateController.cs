using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Pacientes
{
    public class PacientesCreateController : ControllerBase
    {
        private readonly IPacienteRepository _pacienteRepository;
        public PacientesCreateController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

        [HttpPost]
        [Route("api/paciente/create")]
        public IActionResult Create([FromBody] Paciente paciente)
        {
            if(paciente == null)
            {
                return BadRequest("El Objeto es nulo");
            }
            _pacienteRepository.Add(paciente);
            return Ok(new { message = "El Paciente Se Ha Creado Correctamente" });
        }
    }
}