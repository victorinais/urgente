using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace App.Controllers.Pacientes
{
    public class PacientesController : ControllerBase
    {
        private readonly IPacienteRepository _pacienteRepository;

        public PacientesController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

        [HttpGet]
        [Route("api/pacientes")]
        public IEnumerable<Paciente> GetPacientes(){
            return _pacienteRepository.GetAll();
        }
        [HttpGet]
        [Route("api/pacientes/{id}")]
        public Paciente Details(int id){
            return _pacienteRepository.GetById(id);
        }

        [HttpGet("api/citas/count/{id}")]
        public ActionResult<int> GetCitaCountByPacienteId(int id)
        {
            var count = _pacienteRepository.GetCitaCountByPacienteId(id);
            return Ok(new { message = $"El paciente {id} ha tenido {count} citas."});
        }

        [HttpGet("api/historial/{id}")]
        public ActionResult<IEnumerable<Cita>> GetHistorialMedico(int id)
        {
            var historial = _pacienteRepository.GetHistorialMedico(id);
            if (!historial.Any())
            {
                return NotFound(new { message = "No se encontraron citas para este paciente." });
            }
            return Ok(new 
            {
                message = $"Historial médico del paciente con ID {id}",
                historial = historial
            });
        }

    }
}
