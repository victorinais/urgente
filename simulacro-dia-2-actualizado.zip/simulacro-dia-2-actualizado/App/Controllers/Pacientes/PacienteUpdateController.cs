using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;
using App.Services;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Pacientes
{
    public class PacienteUpdateController : ControllerBase
    {
        private readonly IPacienteRepository _pacienteRepository;
        public PacienteUpdateController(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

        [HttpPut("{id}")]
        [Route("api/paciente/update/{id}")]
        public IActionResult Update(int id, [FromBody] Paciente paciente)
        {
            if(paciente == null)
            {
                return BadRequest("El paciente proporcionado no puede ser nulo");
            }

            // Obtener la cita existente por id
            var pacienteExistente = _pacienteRepository.GetById(id);

            // Verificar que la cita existente no sea null
            if (pacienteExistente == null)
            {
                return NotFound($"No se encontró un paciente con el id {id} en la base de datos");
            }

            pacienteExistente.Nombres = paciente.Nombres;
            pacienteExistente.Apellidos = paciente.Apellidos;
            pacienteExistente.FechaNacimiento = paciente.FechaNacimiento;
            pacienteExistente.Correo = paciente.Correo;
            pacienteExistente.Telefono = paciente.Telefono;
            pacienteExistente.Direccion = paciente.Direccion;
            pacienteExistente.Estado = paciente.Estado;

            _pacienteRepository.Update(pacienteExistente);
            return Ok(new { message = "El paciente se actualizó correctamente" });
        }

    }
}