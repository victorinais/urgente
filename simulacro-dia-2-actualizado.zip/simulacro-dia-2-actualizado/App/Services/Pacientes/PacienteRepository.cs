using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Data;
using App.Models;
using Microsoft.EntityFrameworkCore;

namespace App.Services.Pacientes
{
    public class PacienteRepository : IPacienteRepository
    {
        private readonly BaseContext _context;
        public PacienteRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Paciente paciente)
        {
            _context.Pacientes.Add(paciente);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var paciente = _context.Pacientes.Find(id);
            if (paciente!= null)
            {
                paciente.Estado = "inactivo";
                _context.Pacientes.Update(paciente);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Paciente> GetAll()
        {
                var pacientes = _context.Pacientes
                    .Where(p => p.Estado == "activo" || p.Estado == "inactivo" || p.Estado == "pendiente" || p.Estado == "completado")
                    .ToList();
                return pacientes!;
        }

        public Paciente GetById(int id)
        {
            var paciente = _context.Pacientes
               .Where(p => p.Estado == "activo" || p.Estado == "inactivo" || p.Estado == "pendiente" || p.Estado == "completado")
               .FirstOrDefault(p => p.Id == id);
            return paciente!;
        }

        public void Update(Paciente paciente)
        {
            _context.Pacientes.Update(paciente);
            _context.SaveChanges();
        }

        public int GetCitaCountByPacienteId(int id)
        {
            var citaCount = _context.Citas.Where(c => c.PacienteId == id).Count();
            return citaCount;
        }

        public IEnumerable<Cita> GetHistorialMedico(int pacienteId)
        {
            var citas = _context.Citas
               .Include(c => c.Medico)
               .Include(c => c.Tratamientos)
               .Where(c => c.PacienteId == pacienteId)
               .ToList();
            return citas;
        }

    }
}