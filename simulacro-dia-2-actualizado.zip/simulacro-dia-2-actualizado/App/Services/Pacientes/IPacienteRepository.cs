using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;

namespace App.Services
{
    public interface IPacienteRepository
    {
        IEnumerable<Paciente> GetAll();
        Paciente GetById(int id);
        void Add(Paciente paciente);
        void Delete(int id);
        void Update(Paciente paciente);
        int GetCitaCountByPacienteId(int id);
        IEnumerable<Cita> GetHistorialMedico(int pacienteId);
    }
}