using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;

namespace App.Services.Medicos
{
    public interface IMedicoRepository
    {
        IEnumerable<Medico> GetAll();
        Medico GetById(int id);
        void Add(Medico medico);
        void Delete(int id);
        void Update(Medico medico);
    }
}