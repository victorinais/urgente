using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Data;
using App.Models;
using App.Services.Medicos;
using Microsoft.EntityFrameworkCore;

namespace App.Services
{
    public class MedicoRepository : IMedicoRepository
    {
        private readonly BaseContext _context;
        public MedicoRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Medico medico)
        {
            _context.Medicos.Add(medico);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var medico = _context.Medicos.Find(id);
            if (medico!= null)
            {
                medico.Estado = "inactivo";
                _context.Medicos.Update(medico);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Medico> GetAll()
        {
            var medicos = _context.Medicos
                .Include(m => m.Especialidad)
                .Where(m => m.Estado == "activo" || m.Estado == "inactivo" || m.Estado == "pendiente" || m.Estado == "completado")
                .ToList();
            return medicos;
        }

        public Medico GetById(int id)
        {
            var medico = _context.Medicos
               .Include(m => m.Especialidad)
               .Where(m => m.Estado == "activo" || m.Estado == "inactivo" || m.Estado == "pendiente" || m.Estado == "completado")
               .FirstOrDefault(m => m.Id == id);
            return medico!;
        }

        public void Update(Medico medico)
        {
            _context.Medicos.Update(medico);
            _context.SaveChanges();
        }
    }


}