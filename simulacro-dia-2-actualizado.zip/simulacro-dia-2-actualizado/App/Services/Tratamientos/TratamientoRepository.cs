using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Data;
using App.Models;
using Microsoft.EntityFrameworkCore;

namespace App.Services.Tratamientos
{
    public class TratamientoRepository : ITratamientoRepository
    {
        private readonly BaseContext _context;
        public TratamientoRepository(BaseContext context)
        {
            _context = context;
        }
        public void Add(Tratamiento tratamiento)
        {
            _context.Tratamientos.Add(tratamiento);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var tratamiento = _context.Tratamientos.Find(id);
            if (tratamiento!= null)
            {
                _context.Tratamientos.Remove(tratamiento);
                _context.SaveChanges();
            }
        }

        public IEnumerable<Tratamiento> GetAll()
        {
            var tratamientos = _context.Tratamientos
               .Include(t => t.Cita)
               .Where(c => c.Estado == "activo" || c.Estado == "inactivo" || c.Estado == "pendiente" || c.Estado == "completado")
               .ToList();
            return tratamientos;
        }

        public Tratamiento GetById(int id)
        {
            var tratamiento = _context.Tratamientos
               .Include(t => t.Cita)
               .Where(c => c.Estado == "activo" || c.Estado == "inactivo" || c.Estado == "pendiente" || c.Estado == "completado")
               .FirstOrDefault(c => c.Id == id);
            return tratamiento!;
        }

        public void Update(Tratamiento tratamiento)
        {
            _context.Tratamientos.Update(tratamiento);
            _context.SaveChanges();
        }
    }
}