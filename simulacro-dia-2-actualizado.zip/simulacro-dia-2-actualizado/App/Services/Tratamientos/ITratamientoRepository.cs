using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Models;

namespace App.Services.Tratamientos
{
    public interface ITratamientoRepository
    {
        IEnumerable<Tratamiento> GetAll();
        Tratamiento GetById(int id);
        void Add(Tratamiento tratamiento);
        void Delete(int id);
        void Update(Tratamiento tratamiento);
    }
}