namespace Assessment.Models;
public class Transaccion
{
    public int TransaccionId { get; set; } // PK
    public DateTime FechaHora { get; set; }
    public decimal Monto { get; set; }
    public string Estado { get; set; } // Ejemplo: Pendiente, Completada, Fallida
    public string Tipo { get; set; } // Ejemplo: Pago de Factura
    public string PlataformaUtilizada { get; set; } // Ejemplo: Nequi, Daviplata

    // Llaves foráneas y relaciones
    public int ClienteId { get; set; } // FK con Cliente
    public Cliente Cliente { get; set; } 

    public int? FacturaId { get; set; } // FK con Factura (nullable porque una transacción puede no estar asociada a una factura)
    public Factura Factura { get; set; } 
}
