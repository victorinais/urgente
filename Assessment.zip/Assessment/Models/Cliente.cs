namespace Assessment.Models;
public class Cliente
{
    public int ClienteId { get; set; } // PK
    public string Nombre { get; set; }
    public string NumeroIdentificacion { get; set; }
    public string Direccion { get; set; }
    public string Telefono { get; set; }
    public string CorreoElectronico { get; set; }

    // Relaciones
    public ICollection<Transaccion> Transacciones { get; set; } // Relación 1:N con Transacciones
    public ICollection<Factura> Facturas { get; set; } // Relación 1:N con Facturas
}
