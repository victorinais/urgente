namespace Assessment.Models;
public class Factura
{
    public int FacturaId { get; set; } // PK
    public string NumeroFactura { get; set; }
    public string PeriodoFacturacion { get; set; } // Ejemplo: 2024-06
    public decimal MontoFacturado { get; set; }
    public decimal MontoPagado { get; set; }

    // Llaves foráneas y relaciones
    public int ClienteId { get; set; } // FK con Cliente
    public Cliente Cliente { get; set; } 

    public ICollection<Transaccion> Transacciones { get; set; } // Relación 1:N con Transacciones (una factura puede tener varias transacciones)
}
